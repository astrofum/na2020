var searchData=
[
  ['u',['u',['../struct_state.html#a0f2aeac6016e514b2d5f807403e021a4',1,'State']]],
  ['uc',['Uc',['../struct_data.html#a775aa6241086ed4e9eb10fb3c5f11f95',1,'Data']]],
  ['unit_5fdensity',['UNIT_DENSITY',['../pluto_8h.html#a1e411ee12bfbc3e7b61dd978a2faf737',1,'pluto.h']]],
  ['unit_5flength',['UNIT_LENGTH',['../pluto_8h.html#a1b2dfce30d2dd62f2c1a7b3782d50d14',1,'pluto.h']]],
  ['unit_5fvelocity',['UNIT_VELOCITY',['../pluto_8h.html#a038fb4c48089f0cc2e50e9936c1895d8',1,'pluto.h']]],
  ['unsetjetdomain',['UnsetJetDomain',['../jet__domain_8c.html#ad682f5e9f92f10748aea26b3b0aa6a38',1,'jet_domain.c']]],
  ['update_5fstage_2ec',['update_stage.c',['../update__stage_8c.html',1,'']]],
  ['updatestage',['UpdateStage',['../update__stage_8c.html#ad1f0d3402d24f600065098077ccb1cb6',1,'update_stage.c']]],
  ['updateupstreamspectra',['UpdateUpstreamSpectra',['../particles__lp__spectra_8c.html#a4783deaf8460819ad5eed892518e74ab',1,'particles_lp_spectra.c']]],
  ['user_5fvar',['user_var',['../struct_runtime.html#a7ffd0b2c34c7281d1f7537c21e8c205f',1,'Runtime']]],
  ['userdefboundary',['UserDefBoundary',['../init_8c.html#a871556305428fad692c67884bcb270bd',1,'init.c']]]
];
