var searchData=
[
  ['qcr',['qcr',['../struct_data.html#afe6c1ad00f24a8cbb2e718e88eaa9fc1',1,'Data']]]
];
