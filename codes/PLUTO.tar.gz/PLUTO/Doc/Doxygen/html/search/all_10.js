var searchData=
[
  ['qcr',['qcr',['../struct_data.html#afe6c1ad00f24a8cbb2e718e88eaa9fc1',1,'Data']]],
  ['quadraticsolve',['QuadraticSolve',['../math__root__finders_8c.html#ac94da3a96cfafbbd36efb1ecf0cf207e',1,'math_root_finders.c']]],
  ['quartic_2ec',['quartic.c',['../quartic_8c.html',1,'']]],
  ['quarticsolve',['QuarticSolve',['../math__root__finders_8c.html#af5f2bb582dd6942f9dfe5b9e9f2eecc5',1,'QuarticSolve(double b, double c, double d, double e, double *z):&#160;math_root_finders.c'],['../quartic_8c.html#af5f2bb582dd6942f9dfe5b9e9f2eecc5',1,'QuarticSolve(double b, double c, double d, double e, double *z):&#160;quartic.c']]],
  ['quicksort',['QuickSort',['../math__misc_8c.html#aac71f6352ce2c3447b4d0458b048a119',1,'math_misc.c']]],
  ['quit_5fpluto',['QUIT_PLUTO',['../macros_8h.html#a00c035c360a268f5f7c08fd79439eaa9',1,'macros.h']]]
];
