var searchData=
[
  ['kbeg',['kbeg',['../struct_r_box.html#a9346336c4fcf9d39c198fd30e5dea6f5',1,'RBox::kbeg()'],['../globals_8h.html#a18a541468eee3b198c4faa925a66f17b',1,'KBEG():&#160;globals.h'],['../pluto_8h.html#a18a541468eee3b198c4faa925a66f17b',1,'KBEG():&#160;globals.h']]],
  ['kend',['kend',['../struct_r_box.html#a7f3e438293c511c0c9b543aaba3a90ab',1,'RBox::kend()'],['../globals_8h.html#abeed02170047db7422a173d6684fce52',1,'KEND():&#160;globals.h'],['../pluto_8h.html#abeed02170047db7422a173d6684fce52',1,'KEND():&#160;globals.h']]]
];
