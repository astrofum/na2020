var indexSectionsWithContent =
{
  0: "abcdefghijklmnopqrstuvwx",
  1: "degimoprst",
  2: "abcdefghijlmpqrstuvw",
  3: "abcdefghilmnopqrstuvw",
  4: "abcdefghijklmnopqrstuvwx",
  5: "k",
  6: "abcdefgikmnqrstux",
  7: "cgpt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Macros",
  7: "Pages"
};

