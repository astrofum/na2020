var searchData=
[
  ['j',['J',['../struct_data.html#a2f468e1b8bce0697e91a5f001275461f',1,'Data::J()'],['../struct_state.html#a2eaaa1e917edd8bcac5d4de119fa441f',1,'State::J()']]],
  ['jbeg',['jbeg',['../struct_r_box.html#a291ddbc9095ecffeab7b8bd35492ab27',1,'RBox::jbeg()'],['../globals_8h.html#acc5894e44133cd83ca2dbaffc292ab47',1,'JBEG():&#160;globals.h'],['../pluto_8h.html#acc5894e44133cd83ca2dbaffc292ab47',1,'JBEG():&#160;globals.h']]],
  ['jcr',['Jcr',['../struct_data.html#a2b83abcd628e4b3583b8ce89fb706b09',1,'Data']]],
  ['jend',['jend',['../struct_r_box.html#a9997fe4688f68bd1ead96e0536fbc8f0',1,'RBox::jend()'],['../globals_8h.html#a75fa00847521eda88ac50b41866905a4',1,'JEND():&#160;globals.h'],['../pluto_8h.html#a75fa00847521eda88ac50b41866905a4',1,'JEND():&#160;globals.h']]]
];
