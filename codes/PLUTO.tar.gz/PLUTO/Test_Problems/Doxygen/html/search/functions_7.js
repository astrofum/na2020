var searchData=
[
  ['resistive_5feta',['Resistive_eta',['../_m_h_d_2_resistive___m_h_d_2_current___sheet_2res__eta_8c.html#a40ec712d028bfb41c9e617dcdd0330a6',1,'Resistive_eta(double *v, double x1, double x2, double x3, double *J, double *eta):&#160;res_eta.c'],['../_r_m_h_d_2_resistivity_2_rotor_2res__eta_8c.html#ad6d8aed47b95f79fd869b6302c0baaf1',1,'Resistive_eta(double *u, double x1, double x2, double x3):&#160;res_eta.c']]]
];
