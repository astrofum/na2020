var searchData=
[
  ['tc_5fkappa',['TC_kappa',['../_shearing___box_2tc__kappa_8c.html#a5c19f8bcfbe2e52441affa6ead23b70f',1,'tc_kappa.c']]],
  ['tc_5fkappa_2ec',['tc_kappa.c',['../_shearing___box_2tc__kappa_8c.html',1,'']]]
];
