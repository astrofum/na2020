#include "pluto.h"

/* ************************************************************* */
void States (const Sweep *sweep, int beg, int end, Grid *grid)
/* 
 *  PURPOSE
 *    
 *    Empty function. Should be used with finite-difference    
 *
 **************************************************************** */
{


}
